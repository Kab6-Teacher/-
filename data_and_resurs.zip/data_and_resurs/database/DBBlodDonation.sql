﻿CREATE TABLE [dbo].[Edinica](
	[ID_Edinica] [int] IDENTITY(1,1) NOT NULL,
	[GUID_Donor] [nchar](10) NOT NULL,
	[Component] [nchar](6) NOT NULL,
	[FK_Status] [int] NOT NULL,
	[Date_Sbora] [date] NOT NULL,
	[Date_Freeze] [date] NULL,
	[Group] [nchar](1) NOT NULL,
	[Rh] [bit] NULL,
 CONSTRAINT [PK_Edinica] PRIMARY KEY CLUSTERED 
(
	[ID_Edinica] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Status]    Script Date: 15.11.2021 1:26:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Status](
	[ID_Status] [int] IDENTITY(1,1) NOT NULL,
	[Status] [nvarchar](40) NOT NULL,
 CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED (
	[ID_Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
ALTER TABLE [dbo].[Edinica]  WITH CHECK ADD  CONSTRAINT [FK_Edinica_Status] FOREIGN KEY([FK_Status])
REFERENCES [dbo].[Status] ([ID_Status])
GO
ALTER TABLE [dbo].[Edinica] CHECK CONSTRAINT [FK_Edinica_Status]
GO